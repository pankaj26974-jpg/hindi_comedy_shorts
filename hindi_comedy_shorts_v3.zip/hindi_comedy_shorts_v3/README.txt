HINDI COMEDY SHORTS STUDIO — VERSION 3

WHAT IT DOES
- Generates short Hindi comedy scripts from built-in templates.
- Shows a simple scene plan.
- Reads the script aloud using browser/Android Hindi text-to-speech when available.
- Renders a vertical 9:16 animated text-and-emoji video and downloads it as WebM.

IMPORTANT LIMITATIONS
- This is a free prototype, not a full AI video generator.
- It does not generate AI characters, realistic scenes, or images.
- Spoken TTS is a separate preview and is NOT embedded in the exported video.
- Export format is WebM, not MP4. Browser and Android support can vary.
- Keep the page open while rendering.

ANDROID QUICK START
1. Download and extract hindi_comedy_shorts_v3.zip into a NEW folder.
2. Open index.html in Chrome (use your file manager's Open with option if needed).
3. Tap Generate Comedy Short.
4. Tap Render & Save Video and wait for the success message.
5. Check your phone's Downloads folder for hindi-comedy-short-v3.webm.

Do not overwrite Version 2; keep it as a backup.
